import "./Home.css";
import Input from "./Input";
import { useGetData, usePostData } from "../Hook/useData";
import { useForm } from 'react-hook-form';

export default function Home() {
    const { register, handleSubmit, formState: { errors } } = useForm({ mode: "onSubmit", reValidateMode: "onChange" });

    const [data, submitFetch, onError, myError] = usePostData("partners");

    const onSubmit = (data, e) => {
        console.log(data, e);
        submitFetch(data);
    };

    return (
        <>
            <form onSubmit={handleSubmit(onSubmit, () => onError(errors))}>
                <Input
                    name="name"
                    validationSchema={{ required: "Dit veld is verplicht" }}
                    label="Je naam"
                    required
                    errorLog={myError}
                    register={register} />
                <button type="submit" className="button margin">Submit</button>
            </form>
            <div>{data}</div>
        </>
    )
}