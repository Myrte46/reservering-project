import useFetch, { usePost, useDelete, useSingleFetch, usePut } from "./useFetch";
import { useState, useEffect } from "react";

const useGetData = (url) => {

    const [data, setData] = useState();
    const [status, setStatus] = useState();

    useEffect(() => {
        const DoFetch = () => {
            const [getStatus, getResponseData] = useFetch(url);
            console.log("Get log ", getStatus, getResponseData);
            setData(getResponseData);
            setStatus(getStatus);
        }
        DoFetch();
    }, [data, status]);

    return [data?.data, status];
}

const usePostData = (url, data) => {

    const [myError, setMyError] = useState();
    const [submitFetch, setSubmitFetch] = useState();

    useEffect(() => {
        const DoPost = () => {

            const [ setFetch, fetchStatus, responseData] = usePost(url);
            setSubmitFetch(setFetch);

            console.log("Post log ", fetchStatus, responseData);

        }
        DoPost();
    }, [submitFetch]);


    const onError = (errors, e) => {
        console.log(errors, e);
        setMyError(errors);
    }

    return [data?.data, submitFetch, onError, myError];
}

export { useGetData, usePostData }